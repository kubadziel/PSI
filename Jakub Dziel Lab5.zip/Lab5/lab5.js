//ZAD1
function changeText() {
    document.getElementById("p1").style.color = "blue";
    document.getElementById("p1").style.fontFamily = "Arial";
    document.getElementById("p1").style.fontSize = "larger";
}
//ZAD2
function changeSource() {
    document.getElementById("zad2img").src = document.getElementById("zad2input").value;
}
//ZAD3
function addItemToList(){
    let linkUrl = document.getElementById("zad3input_1").value;
    let linkText = document.getElementById("zad3input_2").value;

    let list = document.getElementById("list-zad3");
    let newListPoint = document.createElement("li");

    let newNodeLink = newListPoint.appendChild(document.createElement("a"))

    newNodeLink.setAttribute("href",linkUrl);
    newNodeLink.innerHTML = linkText;
    list.prepend(newListPoint);
}
//ZAD4
function mOver(obj) {
    obj.innerHTML = Date()
}

function mOut(obj) {
    obj.innerHTML = "Mouse Over Me"
}

function onClick() {
    document.getElementById("p4").innerHTML = document.getElementById("move-date").innerHTML;
}
//ZAD5
function changeStyle(obj){
    obj.style = "font-weight: bolder; color: red";
}