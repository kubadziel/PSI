//ZAD1
function getRndInteger(min, max) {
    return Math.floor(Math.random() * (max - min + 1) ) + min;
}
function inputValidation(input, randNumber){
    if (isNaN(input) || input < 1 || input > 10) {
        alert('Niepoprawna wartość. Podaj liczbę od 1 do 10');
    } else if (input === randNumber){
        alert('Trafiłeś');
    }else{
        alert('Pudło, wylosowałem '+randNumber);
    }
}
function parseInteger(input){
    return parseInt(document.getElementById(input).value)
}
function compareValues() {
    let userInput = parseInteger("user-input");
    let randomNumber = getRndInteger(1, 10);
    inputValidation(userInput, randomNumber);
}
//ZAD2
function parseFlt(input){
    return parseFloat(document.getElementById(input).value)
}
function multiplyBy() {
    let num1 = parseFlt("firstNumber");
    let num2 = parseFlt("secondNumber");
    document.getElementById("result").innerHTML = String(num1 * num2);
}
function divideBy() {
    let num1 = parseFlt("firstNumber");
    let num2 = parseFlt("secondNumber");
    document.getElementById("result").innerHTML = String(num1 / num2);
}
//ZAD3
function convertTempCtoF(){
    return document.getElementById("resultCtoF").innerHTML = String((parseFlt("temperatureC") * (9/5)) + 32);
}
function convertTempFtoC(){
    return document.getElementById("resultFtoC").innerHTML = String((parseFlt("temperatureF") - 32) / (1.8000));
}
//ZAD4
function expoNumber() {
    let num1 = parseFlt("number");
    let num2 = parseFlt("expo");
    document.getElementById("resultExp").innerHTML = String(num1 ** num2);
}
//ZAD5
function countFact() {
    let num1 = parseFlt("numberFact");
    var result = 1;
    for (let i = 1; i <= num1; i++){
        result *= i;
    }
    document.getElementById("resultFact").innerHTML = String(result);
}
//ZAD6
function sortArray(){
    var Arr = [ 3, 8, 7, 6, 5, -4, 3, 2, 1 ];
    document.getElementById("sorted-array").innerHTML = String(Arr.sort());
}